//
//  ViewController.m
//  ARAPP
//
//  Created by Rico on 2016/12/2.
//  Copyright © 2016年 Rico. All rights reserved.
//

#import "ViewController.h"
#import "BaiduARSDK.h"
#import "BARConfig.h"
#import "BARTrackingViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)case2:(id)sender {
    [BARConfig sharedInstance].useAsShell = true;
    NSString* bundlePath = [[NSBundle mainBundle] pathForResource:@"resource" ofType:@"bundle"];

    NSString* path = [bundlePath stringByAppendingString:@"/ar_scene"];
    [BARConfig sharedInstance].resPath = path;

    BARTrackingViewController* tVC = [[BARTrackingViewController alloc] initWithCaseId:@"demo"];
    __weak BARTrackingViewController* weakTVC = tVC;
    tVC.closeEventBlock = ^{
        [weakTVC dismissViewControllerAnimated:true completion:nil];
    };
    //self.navigationController.navigationBar.hidden = true;
    [self presentViewController:tVC animated:true completion:nil];
}

@end
