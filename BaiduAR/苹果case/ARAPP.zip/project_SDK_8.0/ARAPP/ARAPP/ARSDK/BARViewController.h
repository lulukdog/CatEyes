//
//  BARViewController.h
//  ARSDK
//
//  Created by LiuQi on 16/1/12.
//  Copyright © 2016年 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BARViewController : UIViewController

typedef void (^BARViewCloseEventBlock)(void);
typedef void (^BARViewClickEventBlock)(NSString* url);

@property (nonatomic, copy) BARViewCloseEventBlock closeEventBlock;
@property (nonatomic, copy) BARViewClickEventBlock clickEventBlock;

@end
