//
//  BARViewController.h
//  ARSDK
//
//  Created by LiuQi on 15/6/17.
//  Copyright (c) 2015年 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

// @class - BARTrackingViewController
// @brief - 跟踪 AR 视图控制器

@interface BARTrackingViewController : UIViewController

typedef void (^BARTrackingViewCloseEventBlock)(void);
typedef void (^BARTrackingViewClickEventBlock)(NSString* url);

// 关闭页面回调
@property (nonatomic, copy) BARTrackingViewCloseEventBlock closeEventBlock;
// 点击事件回调
@property (nonatomic, copy) BARTrackingViewClickEventBlock clickEventBlock;

/**
 * 初始化
 * @param caseId 案例Id
 * @return 实例
 */
- (id)initWithCaseId:(NSString*)caseId;

@end
