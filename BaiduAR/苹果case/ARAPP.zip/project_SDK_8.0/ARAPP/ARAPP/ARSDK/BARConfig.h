//
//  BARConfig.h
//  ARSDK
//
//  Created by LiuQi on 15/8/18.
//  Copyright (c) 2015年 Baidu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BARSDKDelegate.h"

typedef enum {
    BAREnvRDLocal,
    BAREnvRDInternet,
    BAREnvQA,
    BAREnvInternet
}BAREnv;


@interface BARConfig : NSObject

// 类方法
+ (BARConfig *)sharedInstance;

@property (nonatomic,copy) NSString* sdkVersion;
@property (nonatomic,copy) NSString* engineVersion;
@property (nonatomic,copy) NSString* lbsServer;
@property (nonatomic,copy) NSString* trackServer;
@property (nonatomic,copy) NSString* mapServer;
@property (nonatomic,copy) NSString* bundlePath;
@property (nonatomic,copy) NSString* appId;
@property (nonatomic,weak) id<BARSDKDelegate> sdkDelegate;
@property (nonatomic,assign) BOOL useCustomView;
@property (nonatomic, assign) BOOL debugMode;
@property (nonatomic, copy) NSString *uploadLogUrl;
@property (nonatomic, assign) NSInteger cpuGear;
@property (nonatomic,copy) NSString* arValue;
@property (nonatomic, assign) BOOL useAsShell;
@property (nonatomic, assign) BOOL monkeyMode;
@property (nonatomic, copy) NSString* resPath;
@property (nonatomic, assign) NSTimeInterval startTime;

// 获取资源路径
- (NSString*)getResPath:(NSString*)filename;
// 请求中需要携带的公共参数
- (NSDictionary *)composeCommonServerParameter;
- (NSString*)getSystemInfo;
- (NSString*)getIdentifier;

- (NSString*)getCommonARValue;
- (void)setEnv:(BAREnv)env;


- (BOOL)useCustomView;
- (void)reloadConfig;
@end
