//
//  BaiduARSDK.h
//  BaiduARSDK
//
//  Created by LiuQi on 15/6/15.
//  Copyright (c) 2015年 Baidu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BARViewController.h"
#import "BARSDKDelegate.h"

typedef enum {
    kBARTypeUnkonw = 0,
    kBARTypeTracking,
    KBARTypeLBS,
    kBARTypeCoupon
} kBARType;

// @class - BaiduARSDK
// @brief - 百度AR SDK

@interface BaiduARSDK : NSObject

/**
 *获取AR 视图
 */
+ (BARViewController*)viewController:(NSString*)arKey
                              arType:(kBARType)arType
                               arLoc:(NSString*)arLog;

/**
 *获取AR 视图
 */
+ (BARViewController*)viewController:(NSString*)arValue;

/**
 * 清空SDK 缓存
 */
+ (void)cleanCache;

/**
 * 获取SDK 缓存大小
 * @return byte
 */
+ (unsigned long)cacheSize;

/**
 * 设置资源路径,默认为BaiduAR.bundle
 */
+ (void)setBundlePath:(NSString*)path;

/**
 * SDK 版本号
 * @return 版本
 */
+ (NSString*)sdkVersion;

/**
 * 设置 SDK 代理
 */
+ (void)setSDKDelegate:(id<BARSDKDelegate>)delegate;

/**
 *  设置是否使用自定义的indicator和alertView
 */

+ (void)setUseCustomView:(BOOL)use;

/**
 *  离线日志
 */
+ (void)initLog:(NSString *)fileName;
+ (NSString *)getLog;


@end